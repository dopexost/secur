<?php
eval(base64_decode('asdasdasd'))
>